<?php

namespace App\Exceptions;

use Exception;

class ValidationError extends Exception
{
    
}
