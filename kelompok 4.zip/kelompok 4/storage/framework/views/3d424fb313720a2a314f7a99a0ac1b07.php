<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="hero">
        <div class="container text-center sambutan">
            <div class="row justify-content-evenly">
                <div class=" col-xs-6 col-md-6 text-light">
                    <h3>Selamat Datang</h3>
                    <h4>Website SMPN 4 Balige</h4>
                    <p>Menyambut anda di halaman utama
                        sekolah kami - pintu gerbang menuju
                        pengetahuan dan pengalaman yang
                        tak terbatas</p>
                </div>
                <div class=" col-xs-6 col-md-6 mb-5 scroll">
                    <img src="<?php echo e(asset('img/2.jpg')); ?>">
                </div>
            </div>
        </div>
    </div>

    <!--kalimat pembuka-->
    <div class="list">
    </div>
    <div class="container-fluid person">
        <div class="row justify-content-md-center flex-wrap" style="background: rgba(0, 0, 0, 0.5);">
            <div class="col-md-4 col-xl-4">
                <img src="<?php echo e(asset('img/berliana.png')); ?>" width="100" height="100">
            </div>
            <div class="col-md-8 col-xl-8">
                <div class="hero1">
                    <h2>KEPALA SEKOLAH SMPN 4 BALIGE</h2>
                    <h3>Berliana Pasaribu, S.Pd.</h3>
                  <?php if($kata_sambutan): ?>
                        <p><?php echo e($kata_sambutan->isi); ?></p>
                    <?php else: ?>
                        <p>Tidak ada kata sambutan yang dipilih.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
  
    <div class="list">
    </div>

    <!-- Berita/Pengumuman -->
    <div class="latar">
        <div class="container-fluid text-center berita">
            <h2>B E R I T A</h2>
            <div class="row justify-content-evenly">
                <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-10 col-lg-5 news" style="display: flex;justify-content:space-around">
                    <div>
                        <img src="<?php echo e(asset('storage/img/' . $item->file)); ?>" width="100" height="100">
                    </div>
                    <div class="other">
                        <h3><?php echo e($item->judul); ?></h3>
                        <a href="<?php echo e(route('berita.show', ['id' => $item->id])); ?>">Selengkapnnya..</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

               
                
            </div>
        </div>
    </div>
</div>
    
   

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/dashboarduser.blade.php ENDPATH**/ ?>