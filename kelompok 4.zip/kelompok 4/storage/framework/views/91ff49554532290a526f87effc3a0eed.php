<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id=<?php echo e('staticBackdropeditdetailsekolah' . $item->id); ?> data-bs-backdrop="static"
        data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Edit Detail Sekolah <?php echo e($item->id); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('data_sekolah.update', ['id' => $item->id])); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <?php if($item->file): ?>
                                    <center><img class="border shadow"
                                            src="<?php echo e(asset('storage/images/' . $item->file)); ?>" alt="Gambar Profil"
                                            style="max-width: 100px;"></center>
                                <?php endif; ?>
                                <div>
                                    <label for="exampleInputEmail1">Nama Kepala Sekolah</label>
                                    <input type="text" class="form-control" name="nama_kepala_sekolah"
                                        value="<?php echo e($item->nama_kepala_sekolah); ?>" id="exampleInputEmail1">
                                </div>
                                <?php $__errorArgs = ['nama_kepala_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error" style="color: red"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div>
                                    <label for="exampleInputEmail1">Akreditasi</label>
                                    <input type="text" class="form-control" name="akreditas"
                                        value="<?php echo e($item->akreditas); ?>" id="exampleInputEmail1"
                                        placeholder="">
                                </div>
                                <sup>masukkan hanya 1 karakter huruf misalnya "A"</sup>
                                <?php $__errorArgs = ['akreditas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error" style="color: red"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div>
                                    <label for="exampleInputEmail1">Operator</label>
                                    <input type="text" class="form-control" name="operator"
                                        value="<?php echo e($item->operator); ?>" id="exampleInputEmail1"
                                        placeholder="Masukkan Judul Berita">
                                </div>
                                <?php $__errorArgs = ['operator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error" style="color: red"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id=<?php echo e('staticBackdropeditdatasiswa' . $item->id); ?> data-bs-backdrop="static"
        data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Edit Data Siswa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('data_siswa.update', ['id' => $item->id])); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <div>
                                    <label for="exampleInputEmail1">Jumlah Laki-Laki</label>
                                    <input type="text" class="form-control" name="jumlah_laki_laki"
                                        value="<?php echo e($item->jumlah_laki_laki); ?>" id="exampleInputEmail1">
                                </div>
                                <?php $__errorArgs = ['jumlah_laki_laki'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error" style="color: red"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div>
                                    <label for="exampleInputEmail1">Jumlah Perempuan</label>
                                    <input type="text" class="form-control" name="jumlah_perempuan"
                                        value="<?php echo e($item->jumlah_perempuan); ?>" id="exampleInputEmail1">
                                </div>
                                <?php $__errorArgs = ['jumlah_perempuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error" style="color: red"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div>
                                    <label for="exampleInputEmail1">jumlah_tingkat_7</label>
                                    <input type="text" class="form-control" name="jumlah_tingkat_7"
                                        value="<?php echo e($item->jumlah_tingkat_7); ?>" id="exampleInputEmail1">
                                </div>
                                <?php $__errorArgs = ['jumlah_tingkat_7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error" style="color: red"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div>
                                    <label for="exampleInputEmail1">jumlah_tingkat_8</label>
                                    <input type="text" class="form-control" name="jumlah_tingkat_8"
                                        value="<?php echo e($item->jumlah_tingkat_8); ?>" id="exampleInputEmail1">
                                </div>
                                <?php $__errorArgs = ['jumlah_tingkat_8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error" style="color: red"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div>
                                    <label for="exampleInputEmail1">jumlah_tingkat_9</label>
                                    <input type="text" class="form-control" name="jumlah_tingkat_9"
                                        value="<?php echo e($item->jumlah_tingkat_9); ?>" id="exampleInputEmail1">
                                </div>
                                <?php $__errorArgs = ['jumlah_tingkat_7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error" style="color: red"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/modals/modal.blade.php ENDPATH**/ ?>