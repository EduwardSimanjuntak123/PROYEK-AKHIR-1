<?php $__env->startSection('content'); ?>
    <div class="container">
       
        

        <div class="modal fade" id="tambahjabatan" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="staticBackdropLabel" aria-hidden="true">

            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Tambah Jabatan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('jabatan.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Jabatan</label>
                                    <input type="text" placeholder="Masukan Nama Galeri" class="form-control" name="jabatan" id="exampleInputEmail1">
                                    <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color: brown"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-primary">Tambah</button>
                            </div>
                        </form>
                        
                    </div>
        
                </div>
            </div>
        </div>

        <div class="container mb-3">
            <div style="float:right;" >
                <button type="submit" class="btn btn-success" data-bs-toggle="modal"
            data-bs-target="#tambahjabatan">Tambah Jabatan</button>
                <button type="button " class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                    Tambah Guru atau Staff
                </button>
            </div>
        </div>
        <br>



        <div class="container mt-4">
            <div class="table-responsive mt-3">
                <table class="table table-striped table-bordered shadow p-3">
                    <thead class="thead-dark">
                        <tr>
                            <th>No</th>
                            <th>NIP</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>Jabatan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td> <!-- Ubah logika untuk nomor urut -->
                                <td><?php echo e($item->NIP); ?></td> <!-- Pastikan properti nip tersedia -->
                                <td><?php echo e($item->nama); ?></td> <!-- Pastikan properti nama tersedia -->
                                <td><?php echo e($item->jenis_kelamin); ?></td> <!-- Pastikan properti jenis_kelamin tersedia -->
                                <td> <?php echo e($item->jabatan); ?>

                                <td>
                                    <button type="button" class="btn btn-warning" data-bs-toggle="modal"
                                        data-bs-target=<?php echo e('#editgurudanstaff' . $item->id); ?> data-id="<?php echo e($item->id); ?>">
                                        <i class="lni lni-pencil"></i>
                                    </button>
                                    <form action="<?php echo e(route('gurustaff.delete', ['id' => $item->id])); ?>" method="POST"
                                        class="d-inline" onsubmit="return confirm('Delete?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger" onclick="window.deleteConfirm(event)"><i
                                                class="lni lni-trash-can"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


            </div>
        </div>

    </div>


    <?php echo $__env->make('modals.modalgurustaff', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/admin/gurustaff.blade.php ENDPATH**/ ?>