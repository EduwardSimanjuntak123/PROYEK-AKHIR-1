<?php $__env->startSection('content'); ?>
  
        <div class="container">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahsarpras">
                Tambah Fasilitas
            </button>
<?php echo $__env->make('modals.modalsarpras', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <table class="table mt-3 shadow">
                <thead>

                    <tr class="table-secondary">
                        <th scope="col">Nama sarpras </th>
                        <th scope="col">Jumlah sarpras</th>
                        
                        <th scope="col">Aksi</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            
                            <td class="p-3 border"><?php echo e($item->nama_sarpras); ?></td>
                            <td class="p-3 border"><?php echo e($item->jumlah_sarpras); ?></td>
                            <td style="gap:15px; ">
                                <button type="button" class="btn btn-warning" data-bs-toggle="modal"
                                    data-bs-target=<?php echo e('#sarprasedit' . $item->id); ?> data-id="<?php echo e($item->id); ?>">
                                    <i class="lni lni-pencil"></i>
                                </button>

                                
                                <form action="<?php echo e(route('data_sarpras.delete', ['id' => $item->id])); ?>" method="POST" 
                                    class="btn btn-danger p-0" onsubmit="return confirm('Delete?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger m-0" onclick="window.deleteConfirm(event)"><i class="lni lni-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/admin/data_sarpras.blade.php ENDPATH**/ ?>