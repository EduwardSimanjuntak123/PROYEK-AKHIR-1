<?php $__env->startSection('content'); ?>

    
        <div class="container">
            <table class="table table-border caption-top shadow">
                <caption>
                    <h3>Detail Sekolah</h3>
                </caption>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th class="col-md-6 table-secondary">Nama Kepala Sekolah</tj>
                    <td class="col-md-6 "><?php echo e($item->nama_kepala_sekolah); ?></td>
                </tr>
                <tr>
                    <th class="col-md-6 table-secondary">Akreditas</th>
                    <td class="col-md-6 "><?php echo e($item->akreditas); ?></td>
                </tr>
                <tr>
                    <th class="col-md-6 table-secondary">Tahun Ajaran</th>
                    <td class="col-md-6 "><?php echo e($item->tahun_ajaran); ?></td>
                </tr>
                <tr>
                    <th class="col-md-6 table-secondary">Operator</th>
                    <td class="col-md-6 "><?php echo e($item->operator); ?></td>
                </tr>
                <tr>
                    <th class="col-md-6 table-secondary">Aksi </th>
                    <td class="col-md-6 ">
                        <button type="button" class="btn btn-warning" data-bs-toggle="modal"
                            data-bs-target="<?php echo e('#staticBackdropeditdetailsekolah' . $item->id); ?>">
                            <i class="lni lni-pencil"></i>
                        </button>
                    </td>
                </tr>
            </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('modals.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   

            <table class="table table-border caption-top shadow-lg">
                <caption>
                    <h3>Data Siswa</h3>
                </caption>
                <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th class="col-md-6 table-secondary">Jumlah siswa kelas 7</tj>
                    <td class="col-md-6 "><?php echo e($item->jumlah_tingkat_7); ?></td>
                </tr>
                <tr>
                    <th class="col-md-6 table-secondary">Jumlah siswa kelas 8</tj>
                    <td class="col-md-6 "><?php echo e($item->jumlah_tingkat_8); ?></td>
                </tr>
                <tr>
                    <th class="col-md-6 table-secondary">Jumlah siswa kelas 9 </tj>
                    <td class="col-md-6 "><?php echo e($item->jumlah_tingkat_9); ?></td>
                </tr>
                <tr>
                    <th class="col-md-6 table-secondary">Laki-Laki </tj>
                    <td class="col-md-6 "><?php echo e($item->jumlah_laki_laki); ?></td>
                </tr>
                <tr>
                    <th class="col-md-6 table-secondary">Perempuan </th>
                    <td class="col-md-6 "><?php echo e($item->jumlah_perempuan); ?></td>
                </tr>
                <tr>
                    <th class="col-md-6 table-secondary">Aksi </th>
                    <td class="col-md-6 ">
                        <button type="button" class="btn btn-warning" data-bs-toggle="modal"
                            data-bs-target="<?php echo e('#staticBackdropeditdatasiswa' . $item->id); ?>">
                            <i class="lni lni-pencil"></i>
                        </button>
                    </td>
                </tr>
            </table>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/admin/data_sekolah.blade.php ENDPATH**/ ?>