<?php $__env->startSection('content'); ?>
    <h1>Kelola Kritik</h1>
    <?php $__currentLoopData = $kritiks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kritik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <h2><?php echo e($kritik->nama ?? 'Anonymous'); ?></h2>
            <p><?php echo e($kritik->isi_kritik); ?></p>
            <form action="<?php echo e(route('admin.kritik.update', $kritik->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <label>
                    <input type="checkbox" name="ditampilkan" value="1" <?php echo e($kritik->ditampilkan ? 'checked' : ''); ?>>
                    Tampilkan
                </label>
                <button type="submit">Update</button>
            </form>
            <?php $__currentLoopData = $kritik->balasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <p><?php echo e($balas->isi_balasan); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <form action="<?php echo e(route('admin.kritik.reply', $kritik->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <textarea name="isi_balasan" placeholder="Balasan"></textarea>
                <button type="submit">Balas</button>
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/admin/kritik.blade.php ENDPATH**/ ?>