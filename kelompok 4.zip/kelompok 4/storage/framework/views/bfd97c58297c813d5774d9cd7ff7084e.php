<?php $__env->startSection('content'); ?>
    <div class="container">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahgaleri">
            Tambah Foto
        </button>

        <div class="container mt-3">
            <h2 class="mb-3 text-center">Achievement</h2>
            <div class="row">
                <?php $__currentLoopData = $achievement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 image-container text-center">
                        <img class="border shadow m-1" src="<?php echo e(asset('storage/images/' . $item->file)); ?>"
                            alt="<?php echo e($item->nama_galeri); ?>" style="width: 100px; height: 100px; object-fit: cover;">
                        <p style="margin: 0.5em 0;"><?php echo e($item->nama_galeri); ?></p>
                        <form action="<?php echo e(route('galeri.delete', ['id' => $item->id])); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"
                                onclick="window.deleteConfirm(event)">hapus</button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <h2 class="mb-3 mt-5 text-center">Activity</h2>
            <div class="row">
                <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 image-container text-center">
                        <img class="border shadow m-1" src="<?php echo e(asset('storage/images/' . $item->file)); ?>"
                            alt="<?php echo e($item->nama_galeri); ?>" style="width: 100px; height: 100px; object-fit: cover;">
                        <p style="margin: 0.5em 0;"><?php echo e($item->nama_galeri); ?></p>
                        <form action="<?php echo e(route('galeri.delete', ['id' => $item->id])); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"
                                onclick="window.deleteConfirm(event)">hapus</button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <?php echo $__env->make('modals.modalgaleri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/admin/galeri.blade.php ENDPATH**/ ?>