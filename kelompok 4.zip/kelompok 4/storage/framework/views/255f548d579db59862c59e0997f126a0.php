<?php $__env->startSection('content'); ?>
    <div class="container all">
        <div class="container-fluid text-center isi ">
            <h1>GALERI SMP NEGERI 4 BALIGE</h1>
        </div>

        <div class="container-fluid text-center foto">
            <div class="row">
                <div>
                    <h2>Achievement</h2>
                </div>
                <?php $__currentLoopData = $achievement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-sm-6 col-lg-4 mb-4">
                        <img class="thumbnail" src="<?php echo e(asset('storage/images/' . $item->file)); ?>"
                            alt="<?php echo e($item->nama_galeri); ?>">
                        <p><?php echo e($item->nama_galeri); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div>
                    <h2>Activity</h2>
                </div>
                <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-sm-6 col-lg-4 mb-4">
                        <img class="thumbnail" src="<?php echo e(asset('storage/images/' . $item->file)); ?>"
                            alt="<?php echo e($item->nama_galeri); ?>">
                        <p><?php echo e($item->nama_galeri); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div id="modal" class="modal">
                <span class="close">&times;</span>
                <img class="modal-content" id="fullImage">
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/galeri.blade.php ENDPATH**/ ?>