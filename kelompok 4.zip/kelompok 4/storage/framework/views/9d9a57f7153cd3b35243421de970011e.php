
    

        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.49), rgba(0, 0, 0, 0.49)), url(/img/2.jpg);
            background-size:cover;
            /* opacity: ; */
            /* background: linear-gradient(0deg, rgba(0, 0, 0, 0.49), rgba(0, 0, 0, 0.49)), url(2.jpg); */
        }
        .login-container {
            background: rgba(230, 227, 227, 0.91);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
            width: 25%;
            height: 50%;
            text-align: center;
        }
        .login-container h2 {
            margin-bottom: 20px;
            font-size: 30px;
        }
        .login-container input {
            width: 80%;
            padding: 20px;
            margin: 10px 0;
            /* border: 1px solid #ccc; */
            border-radius: 5px;
            background: rgba(230, 227, 227, 0.91);

        }
        .login-container button {
            width: 50%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #023768;
            color: white;
            font-size: 16px;
        }
        input{
            text-align: center;
            font-family: "Kaisei Tokumin";
        }
        .login-container a{
            text-decoration: none;
            color: black;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>LOGIN</h2>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" name="email" id="username" placeholder="Your Email" required>
            <input type="password" name="password" id="password" placeholder="Your Password" required>
            <button type="submit">Login</button>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </form>
        <a href="/"><p>Back?</p></a>
    </div>
</body>
</html>
<?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/auth/login.blade.php ENDPATH**/ ?>