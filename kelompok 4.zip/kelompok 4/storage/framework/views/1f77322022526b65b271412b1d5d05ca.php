<?php $__env->startSection('content'); ?>
<div class="container-fluid text-center berita">
    <div class="row">
      <div class="col-8 left">
        <h2><?php echo e($berita->judul); ?></h2>
        <div class="container">
          <img src="<?php echo e(asset('storage/img/' . $berita->file)); ?>" width="200" height="150"><br>
          <h6 id="current-date"></h6>
          <p style="text-align: justify"><?php echo e($berita->isi); ?></p>
        </div>
      </div>
      <div class="col-4 right">
        <?php $__currentLoopData = $beritaku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="side">
          <div class="col-5">
            <img src="<?php echo e(asset('storage/img/' . $berita->file)); ?>" width="100" height="100">
          </div>
          <div class="col-7">
            <h6><?php echo e($berita->judul); ?></h6>
            <a href="<?php echo e(route('berita.show', ['id' => $berita->id])); ?>">Selengkapnnya</a>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      </div>
    </div>
  </div>
    <!--Tampilan isi berita-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/show_berita.blade.php ENDPATH**/ ?>