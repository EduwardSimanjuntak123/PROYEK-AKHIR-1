<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <div class="mb-3 text-end">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                data-bs-target="<?php echo e('#staticBackdroptambahkatasambutan'); ?>">
               Tambah Kata Sambutan
            </button>
        </div>
        <table class="table table-border shadow">
            <thead>
                <tr>
                    <th class="text-center">Kata Sambutan</th>
                   
                    <th class="text-center">Tampilkan</th> 
                    <th class="text-center">Aksi</th> <!-- Kolom untuk radio button -->
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="col-md-4"><?php echo e($item->isi); ?></td>
                        <td class="col-md-2 text-center">
                            <form action="<?php echo e(route('update-tampilkan-ke-user', $item->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="radio" name="tampilkan_ke_user" value="<?php echo e($item->id); ?>" <?php echo e($item->tampilkan_ke_user ? 'checked' : ''); ?> onchange="this.form.submit()">
                                <?php if($item->tampilkan_ke_user): ?>
                                Ditampilkan
                            <?php else: ?>
                               <p></p>
                            <?php endif; ?>
                            </form>
                        </td>
                        <td class="col-md-2 text-center">
                            <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="<?php echo e('#staticBackdropeditkatasambutan' . $item->id); ?>">
                                <i class="lni lni-pencil"></i>
                            </button>
                            <form action="<?php echo e(route('kata_sambutan.delete', ['id' => $item->id])); ?>" method="POST"
                                class="d-inline" onsubmit="return confirm('Delete?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger" onclick="window.deleteConfirm(event)"><i
                                        class="lni lni-trash-can"></i></button>
                            </form>
                        </td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <?php echo $__env->make('modals.modalkatasambutan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/admin/kata_sambutan.blade.php ENDPATH**/ ?>