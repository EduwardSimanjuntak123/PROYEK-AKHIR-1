<?php $__env->startSection('content'); ?>
    <!--overflow-->
    <div class="container-fluid scrolldown">
        <h1>Fasilitas-fasilitas yang ada di SMPN 4 BALIGE</h1>
        <div class="container-fluid text-center">
            <div class="row row-cols-2 justify-content-evenly">
                <div class="col-6">
                    <img src="<?php echo e(asset('img/hero2.jpg')); ?>" width="300" height="300">
                    <h4>Tata Usaha</h4>
                </div>
                <div class="col-6">
                    <img src="<?php echo e(asset('img/hero2.jpg')); ?>" width="300" height="300">
                    <h4>Ruang Lab</h4>
                </div>
                <div class="col-6">
                    <img src="<?php echo e(asset('img/hero2.jpg')); ?>" width="300" height="300">
                    <h4>Ruang Kelas</h4>
                </div>
                <div class="col-6">
                    <img src="<?php echo e(asset('img/hero2.jpg')); ?>" width="300" height="300">
                    <h4>Kebun Modern</h4>
                </div>
            </div>
        </div>
    </div>

    <div class="list">
    </div>

    <!--Data Sarpras-->
    <div style="background-color: #fff;" class="container-fluid">

        <div class="container-fluid text-center sarpras">
            <div class="row">
                <div class="tabel">
                    <table class="table table-bordered">
                        <thead>
                            <h2>DATA SARANA DAN PRASARANA (SARPRAS)</h2>
                            <tr>
                                <th>No</th>
                                <th>Jenis Sarpras</th>
                                <th>Jumlah Satuan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $fasilitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(($fasilitas->currentPage() - 1) * $fasilitas->perPage() + $loop->iteration); ?>

                                    </td>
                                    <td><?php echo e($item->nama_sarpras); ?></td>
                                    <td><?php echo e($item->jumlah_sarpras); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <div>
                        <div style="float: right"><?php echo e($fasilitas->links()); ?><< /div>/div>
                        </div>

                    </div>
                </div>
            </div>
        <?php $__env->stopSection(); ?>
        <!--fasilitas-->

<?php echo $__env->make('layouts_user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/fasilitas.blade.php ENDPATH**/ ?>