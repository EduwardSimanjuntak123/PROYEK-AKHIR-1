<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>Nama</th>
                        <th>Ulasan</th>
                        <th>Balasan</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kritiks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kritik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width: 100px"><?php echo e($kritik->nama ?? 'Anonymous'); ?></td>
                            <td><?php echo e($kritik->isi_kritik); ?></td>
                            <td>
                                <?php $__currentLoopData = $kritik->balasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mb-2">
                                        <p class="mb-1"><?php echo e($balas->isi_balasan); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td style="width: 100px">
                                <div style="display: inline-flex; gap:0.5rem;">
                                    <form action="<?php echo e(route('kritik.update', $kritik->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="ditampilkan"
                                            value="<?php echo e($kritik->ditampilkan ? '0' : '1'); ?>">
                                        <button type="submit"
                                            class="btn btn-sm <?php echo e($kritik->ditampilkan ? 'btn-warning' : 'btn-success'); ?>">
                                            <?php echo e($kritik->ditampilkan ? 'Sembunyikan' : 'Tampilkan'); ?>

                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('kritik.destroy', $kritik->id)); ?>" method="POST"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('Apakah Anda yakin ingin menghapus kritik ini?')">Hapus</button>
                                    </form>
                                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                        data-bs-target="#balasan<?php echo e($kritik->id); ?>">Balas</button>
                                </div>

                                <!-- Modal balasan -->
                                <div class="modal fade" id="balasan<?php echo e($kritik->id); ?>" data-bs-backdrop="static"
                                    data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="staticBackdropLabel">Buat Balasan</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?php echo e(route('kritik.reply', ['id' => $kritik->id])); ?>"
                                                    method="POST" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="card-body">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Masukkan Balasan Anda</label>
                                                            <input type="text" class="form-control" name="isi_balasan"
                                                                id="exampleInputEmail1">
                                                            <?php $__errorArgs = ['isi_balasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <small style="color: brown"><?php echo e($message); ?></small>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Batal</button>
                                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYEK-AKHIR-1\spempat\resources\views/admin/kritik/index.blade.php ENDPATH**/ ?>